﻿using StudentManagementSystem.Data;
using StudentManagementSystem.Interfaces;
using StudentManagementSystem.Models;
using StudentManagementSystem.Service;

class Program
{
    static void Main()
    {
        string connectionString = "Server=(localdb)\\MSSQLLocalDB;Database=Studentlar;Trusted_Connection=True;";
        IStudentRepository studentRepository = new StudentRepository(connectionString);
        IStudentService studentService = new StudentService(studentRepository);

        while (true)
        {
            Console.WriteLine("1. Ro'yxatdan o'tkazish");
            Console.WriteLine("2. Barcha talabalarni ko'rish");
            Console.WriteLine("3. Talaba ma'lumotini yangilash");
            Console.WriteLine("4. Talabani o'chirish");
            Console.WriteLine("5. Talabani ID orqali olish");
            Console.WriteLine("0. Chiqish");
            Console.Write("Tanlang: ");

            string tanlov = Console.ReadLine();
            Console.WriteLine();

            switch (tanlov)
            {
                case "1":
                    AddStudent(studentService);
                    break;
                case "2":
                    ShowAll(studentService);
                    break;
                case "3":
                    UpdateStudent(studentService);
                    break;
                case "4":
                    DeleteStudent(studentService);
                    break;
                case "5":
                    GetStudentById(studentService);
                    break;
                case "0":
                    return;
                default:
                    Console.WriteLine("Noto‘g‘ri tanlov.");
                    break;
            }
        }
    }



    static void AddStudent(IStudentService service)
    {
        Console.Write("Ism: ");
        string ism = Console.ReadLine();

        Console.Write("Familiya: ");
        string familiya = Console.ReadLine();

        Console.Write("Yosh: ");
        int yosh = int.Parse(Console.ReadLine());

        var student = new Student
        {
            Ism = ism,
            Familiya = familiya,
            Yosh = yosh,
        };

        service.Registration(student);
        Console.WriteLine("Talaba muvaffaqiyatli qo‘shildi.");
    }

    static void ShowAll(IStudentService service)
    {
        var list = service.GetAll();

        // Har bir ustun uchun kenglikni belgilaymiz
        int idWidth = 5;
        int ismWidth = 15;
        int familiyaWidth = 15;
        int yoshWidth = 5;

        // Sarlavha
        Console.WriteLine(
            $"{"ID".PadRight(idWidth)}| " +
            $"{"Ism".PadRight(ismWidth)}| " +
            $"{"Familiya".PadRight(familiyaWidth)}| " +
            $"{"Yosh".PadRight(yoshWidth)}| "
        );

        Console.WriteLine(new string('-', idWidth + ismWidth + familiyaWidth + yoshWidth + 15));

        foreach (var s in list)
        {
            Console.WriteLine(
                $"{s.Id.ToString().PadRight(idWidth)}| " +
                $"{s.Ism.PadRight(ismWidth)}| " +
                $"{s.Familiya.PadRight(familiyaWidth)}| " +
                $"{s.Yosh.ToString().PadRight(yoshWidth)}| " 
            );
        }

    }

    static void UpdateStudent(IStudentService service)
    {
        Console.Write("ID: ");
        int id = int.Parse(Console.ReadLine());

        Console.Write("Yangi ism: ");
        string ism = Console.ReadLine();

        Console.Write("Yangi familiya: ");
        string familiya = Console.ReadLine();

        Console.Write("Yangi yosh: ");
        int yosh = int.Parse(Console.ReadLine());

        var student = new Student
        {
            Id = id,
            Ism = ism,
            Familiya = familiya,
            Yosh = yosh
        };

        service.UpdateById(student);
        Console.WriteLine("Ma'lumotlar yangilandi.");
    }

    static void DeleteStudent(IStudentService service)
    {
        Console.Write("ID: ");
        int id = int.Parse(Console.ReadLine());

        service.DeleteById(id);
        Console.WriteLine("Talaba o‘chirildi.");
    }

    static void GetStudentById(IStudentService service)
    {
        Console.Write("ID: ");
        int id = int.Parse(Console.ReadLine());

        var s = service.GetById(id);

        if (s == null)
        {
            Console.WriteLine("Talaba topilmadi.");
        }
        else
        {
            Console.WriteLine($"ID: {s.Id}");
            Console.WriteLine($"Ism: {s.Ism}");
            Console.WriteLine($"Familiya: {s.Familiya}");
            Console.WriteLine($"Yosh: {s.Yosh}");
        }
    }
}
