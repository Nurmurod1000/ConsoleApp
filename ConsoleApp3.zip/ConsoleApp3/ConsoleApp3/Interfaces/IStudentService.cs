﻿using StudentManagementSystem.Models;

namespace StudentManagementSystem.Interfaces;

public interface IStudentService
{
    public void Registration(Student student);
    public Student GetById(int id);
    public List<Student> GetAll();
    public void DeleteById(int id);
    public void UpdateById(Student student);
}
