﻿using StudentManagementSystem.Models;

namespace StudentManagementSystem.Interfaces;

public interface IStudentRepository
{
    // o'quvchi qo'shish uchun
    void Add(Student student);

    //O'quvchilarni Id orqali olish uchun
    Student GetById(int id);
    // Barcha O'quvchilarni db olish uchun
    List<Student> GetAll();

    // o'quvchi update qilish uchun
    void Update(Student student);

    // o'quvchi delete qilish uchun
    void Delete(int id);
}
