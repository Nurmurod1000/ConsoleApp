﻿namespace StudentManagementSystem.Models;

public class Student
{
    public int Id { get; set; }
    public string Ism { get; set; }
    public string Familiya { get; set; }
    public int Yosh { get; set; }
}
