﻿using StudentManagementSystem.Interfaces;
using StudentManagementSystem.Models;
using System.Data.SqlClient;


namespace StudentManagementSystem.Data;

public class StudentRepository : IStudentRepository
{
    private readonly string _connectionString;

    public StudentRepository(string connectionString)
    {
        _connectionString = connectionString;
    }

    public void Add(Student student)
    {
        using SqlConnection conn = new SqlConnection(_connectionString);
        conn.Open();

        SqlCommand cmd = new SqlCommand("sp_AddStudent", conn);
        cmd.CommandType = System.Data.CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@Ism", student.Ism);
        cmd.Parameters.AddWithValue("@Familiya", student.Familiya);
        cmd.Parameters.AddWithValue("@Yosh", student.Yosh);

        cmd.ExecuteNonQuery();
    }

    public void Delete(int id)
    {
        using SqlConnection conn = new SqlConnection(_connectionString);
        conn.Open();

        SqlCommand cmd = new SqlCommand("sp_DeleteStudent", conn);
        cmd.CommandType = System.Data.CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@Id", id);

        cmd.ExecuteNonQuery();
    }

    public List<Student> GetAll()
    {
        var list = new List<Student>();

        using SqlConnection conn = new SqlConnection(_connectionString);
        conn.Open();

        SqlCommand cmd = new SqlCommand("sp_GetAllStudents", conn);
        cmd.CommandType = System.Data.CommandType.StoredProcedure;

        using SqlDataReader reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            list.Add(new Student
            {
                Id = (int)reader["Id"],
                Ism = reader["Ism"].ToString(),
                Familiya = reader["Familiya"].ToString(),
                Yosh = (int)reader["Yosh"]
            });
        }

        return list;
    }

    public Student GetById(int id)
    {
        using SqlConnection conn = new SqlConnection(_connectionString);
        conn.Open();

        SqlCommand cmd = new SqlCommand("sp_GetStudentById", conn);
        cmd.CommandType = System.Data.CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@Id", id);

        using SqlDataReader reader = cmd.ExecuteReader();
        if (reader.Read())
        {
            return new Student
            {
                Id = (int)reader["Id"],
                Ism = reader["Ism"].ToString(),
                Familiya = reader["Familiya"].ToString(),
                Yosh = (int)reader["Yosh"]
            };
        }

        return null;
    }

    public void Update(Student student)
    {
        using SqlConnection conn = new SqlConnection(_connectionString);
        conn.Open();

        SqlCommand cmd = new SqlCommand("sp_UpdateStudent", conn);
        cmd.CommandType = System.Data.CommandType.StoredProcedure;

        cmd.Parameters.AddWithValue("@Id", student.Id);
        cmd.Parameters.AddWithValue("@Ism", student.Ism);
        cmd.Parameters.AddWithValue("@Familiya", student.Familiya);
        cmd.Parameters.AddWithValue("@Yosh", student.Yosh);

        cmd.ExecuteNonQuery();
    }

}
